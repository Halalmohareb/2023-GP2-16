//https://github.com/homaily/Saudi-Arabia-Regions-Cities-and-Districts
List cities = [
  {
    "city_id": 3,
    "region_id": 1,
    "name_ar": "الرياض",
  },
  {
    "city_id": 18,
    "region_id": 2,
    "name_ar": "جدة",
  },
  {
    "city_id": 6,
    "region_id": 2,
    "name_ar": "مكة",
  },
  {
    "city_id": 14,
    "region_id": 3,
    "name_ar": "المدينة",
  },
  {
    "city_id": 13,
    "region_id": 5,
    "name_ar": "الدمام",
  },
  {
    "city_id": 12,
    "region_id": 5,
    "name_ar": "الهفوف",
  },
  {
    "city_id": 5,
    "region_id": 2,
    "name_ar": "الطايف",
  },
  {
    "city_id": 1,
    "region_id": 7,
    "name_ar": "تبوك",
  },
  {
    "city_id": 11,
    "region_id": 4,
    "name_ar": "بريدة",
  },
  {
    "city_id": 62,
    "region_id": 6,
    "name_ar": "خميس مشيط",
  },
  {
    "city_id": 113,
    "region_id": 5,
    "name_ar": "الجبيل",
  },
  {
    "city_id": 3417,
    "region_id": 11,
    "name_ar": "نجران",
  },
  {
    "city_id": 2748,
    "region_id": 5,
    "name_ar": "المبرز",
  },
  {
    "city_id": 10,
    "region_id": 8,
    "name_ar": "حائل",
  },
  {
    "city_id": 15,
    "region_id": 6,
    "name_ar": "ابها",
  },
  {
    "city_id": 483,
    "region_id": 3,
    "name_ar": "ينبع",
  },
  {
    "city_id": 2213,
    "region_id": 9,
    "name_ar": "عرعر",
  },
  {
    "city_id": 80,
    "region_id": 4,
    "name_ar": "عنيزة",
  },
  {
    "city_id": 2237,
    "region_id": 13,
    "name_ar": "سكاكا",
  },
  {
    "city_id": 17,
    "region_id": 10,
    "name_ar": "جازان",
  },
  {
    "city_id": 2226,
    "region_id": 13,
    "name_ar": "القريات",
  },
  {
    "city_id": 2693,
    "region_id": 8,
    "name_ar": "الباحة",
  },
  {
    "city_id": 1301,
    "region_id": 6,
    "name_ar": "بيشة",
  },
  {
    "city_id": 2421,
    "region_id": 4,
    "name_ar": "الرس",
  },
  {
    "city_id": 14519,
    "region_id": 6,
    "name_ar": "الشفا",
  },
];
