import 'package:flutter/material.dart';

var kBackgroundColor = Color(0xffF9F9F9);
var kWhiteColor = Color(0xffffffff);
var kOrangeColor = Color(0xffEF716B);
var kBlueColor = Color(0xff2d99cd);
var kYellowColor = Color(0xffFFB167);
var kTitleTextColor = Color(0xff1E1C61);
var kSearchBackgroundColor = Color(0xffF2F2F2);
var kFillColor = Color(0xffF0F0F0);

String moyasarAPIKey = 'pk_test_J5DLZVGe579PKmeXYK5v4rdBFK5YQwusMFFtyMiD';
String defaultAvatar =
    'https://firebasestorage.googleapis.com/v0/b/dhyaa-application-87f85.appspot.com/o/files%2Favatar.png?alt=media&token=ed50a0a7-96ff-4794-adfd-ea30b01dcace';
