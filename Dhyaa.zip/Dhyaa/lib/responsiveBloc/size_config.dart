import 'package:flutter/widgets.dart';

class SizeConfig {
  static double _screenHeight = 0;
  static double _screenWidth = 0;
  static double _blockHorizontal = 0;
  static double _blockVertical = 0;
  static double textMultiplier = 0;
  static double imageSizeMultiplier = 0;
  static double heightMultiplier = 0;
  static double widthMultiplier = 0;

  static bool isPortrait = true;
  static bool isMobilePortrait = false;

  void init(BoxConstraints constraints, Orientation orientation) {
    if (orientation == Orientation.portrait) {
      _screenWidth = constraints.maxWidth;
      _screenHeight = constraints.maxHeight;
      isPortrait = true;
      if (_screenWidth < 490) {
        isMobilePortrait = true;
      }
    } else {
      _screenWidth = constraints.maxHeight;
      _screenHeight = constraints.maxWidth;
      isPortrait = false;
      isMobilePortrait = false;
    }

    _blockHorizontal = _screenWidth / 100;
    _blockVertical = _screenHeight / 100;

    textMultiplier = _blockVertical;
    imageSizeMultiplier = _blockHorizontal;
    heightMultiplier = _blockVertical;
    widthMultiplier = _blockHorizontal;

    print(_blockHorizontal);
    print(_blockVertical);
    print(_screenWidth);
  }
}
